﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyProject
{
    enum Marks
    {
        Awful = 1,
        Bad = 2,
        Normal = 3,
        Good = 4,
        Great = 5
    }
}

